# car_dent_task > 2025-01-25 1:37pm
https://universe.roboflow.com/prrajwal-nsyfw/car_dent_task

Provided by a Roboflow user
License: CC BY 4.0

